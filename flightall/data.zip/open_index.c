open_index()
{

	web_add_cookie("MUID=37D44E90795463D4381443127D546284; DOMAIN=www.bing.com");

	web_url("index.htm", 
		"URL=http://127.0.0.1:1080/WebTours/index.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://www.bing.com/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_custom_request("q.cgi", 
		"URL=http://conna.gj.qq.com/q.cgi", 
		"Method=POST", 
		"Resource=1", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"EncType=application/octet-stream", 
		"BodyBinary=\\x00\n\\x01\\x8B\\x008R\\x00\\x00\\x00\\x00\\xB8\\x00\\x00\\x00\\x02\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x01\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00R\\xC8\\xD8-Q(\\xAF\\xB4\\xC7\\x91\\x07\\x12\\x7F\\xD0:m\\xB7\\x8A@J\\x05\\xD8\\xF8\\x8D\\x84\\xD5\\xC2\\x9Egh#\\x11\\xCEr\\xF9t\\xFDRS\\x8F\\xA7\\x0C\\xB9\\xA5\\xBF\\xCD\\xC078\\xFDD{nB\\xE1\\xFD\\xA8|"
		"q5N\\x808\\x1DYvq\\x0FB \\xFFg\\xCB\\xB7oC\\x12\\xD6\\xA1@xI5]\\x9C\\xA3\\x16\\xE4q\\x98\\xE2G\\xDC\\x04T\\xA52\\xE4\\xBBi\\xD5\\xE7\\x99\\xC6\\xFCT\\x89\\xC7\\xB4\\xBE\\x17\\x98*\\xB0\\x92L\\xD2j+a\\x8F\\x98m\\xA24[\\xD4\\xB4", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "TLS1.1");

	return 0;
}
